/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fatfs_sd.h"
#include "string.h"
#include "stdio.h"
#include <math.h>
#include <stdint.h>
#include <stdbool.h>
uint16_t dac_value=500;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

DAC_HandleTypeDef hdac;

SPI_HandleTypeDef hspi4;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim13;

osThreadId RecordHandle;
osThreadId MainControllerHandle;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM13_Init(void);
static void MX_SPI4_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM2_Init(void);
void StartDefaultTask(void const * argument);
void StartTask02(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// ────────────── ⏱ Timer & Counter Variables ──────────────
uint32_t MainTaskCount    = 0;
uint32_t RecordTaskCount  = 0;

// ────────────── 📟 Encoder Tick Counters ──────────────
uint32_t encoder_ticks    = 0;        // Current tick count from Encoder 1
uint32_t encoder_ticks_prev = 0;     // Previous tick count from Encoder 1
uint32_t encoder_ticks2   = 0;        // Current tick count from Encoder 2
uint32_t encoder_ticks2_prev = 0;    // Previous tick count from Encoder 2

// ────────────── ⏲ Counters for Events ──────────────
uint32_t MainloopCount    = 0;        // Main loop counter to track loop iterations or events
uint32_t SDCardCount      = 0;        // SD card related counter
uint32_t record_number    = 1;        // Record number counter
uint32_t communicationError = 0;      // Counter for communication errors

// ────────────── ⏳ Timing Variables ──────────────
uint32_t time_interval    = 5;        // Time interval in milliseconds (0.005 seconds at 20 kHz Timer)
uint32_t time_start       = 0;
uint32_t time_end         = 0;
uint32_t secondFromStart  = 0;

// ────────────── 🗄 File System Variables ──────────────
FATFS fs;                         // FatFs structure to manage the file system
FIL fil;                          // File object structure for file operations
FRESULT fresult;                  // Result variable to capture FatFs API function responses

// ────────────── 💾 Buffer for SD Card Operations ──────────────
char buffer[2048];                // Buffer for storing data during SD card operations
UINT br;                           // Bytes read from the file
UINT bw;                           // Bytes written to the file

// ────────────── 🧪 Test & Algorithm Variables ──────────────
FRESULT fresult2;
volatile int EncoderUpdated = 0;
int SDCardRecordMode = 0;

// ────────────── 🚀 Algorithm Code Variables ──────────────
#define CPR 106496.0f//(4096*26)         // Counter Per Revolution
#define MAX_COUNT 65535*26

// Position (angles in rad) for Encoder 1 and Encoder 2
int16_t prev_ticks1 = 0, prev_ticks2 = 0;    // Previous counts for each encoder
float theta1 = 0.0, theta2 = 0.0;
float theta1_prev = 0.0, theta2_prev = 0.0;

// Velocity calculations
float velocity1 = 0.0, velocity2 = 0.0;
float velocity1_prev = 0.0, velocity2_prev = 0.0;
float velocity1Filtered=0.0,velocity2Filtered=0.0;
// Acceleration calculations
float acceleration1 = 0.0, acceleration2 = 0.0;
float acceleration1_prev=0.0;
// ────────────── 🛠 Parameters ──────────────
#define G 90     // Smoothing factor for velocity filter
#define G2 90     // Smoothing factor for velocity filter
// ────────────── ⚙️ Motor 2 Parameters ──────────────
float Icmd2 = 1.1;      // Commanded current (A)
float Ktn2 = 0.0705;    // Torque constant (Nm/A)
float Jn2 = +3069.1e-7; // Motor inertia (kg·m^2)
float Gdis2 = 95.0;     // Disturbance observer gain
float Kt2 = 0.0705;     // Additional torque constant scaling
float Grtob2 = 45.0;    // Reaction torque observer gain
float Fint2 = 0.08;     // Internal force (Nm)
float Ffric2 = 0.04;    // Friction force (Nm)

// ────────────── ⚙️ Motor 1 Physical and Control Parameters ──────────────
float gear_ratio = 26.0f;                   // Gear ratio
float commanded_current = 0.0f;             // Icmd1: Commanded current (A)
float torque_constant_motor = 1.5365f;      // Ktn1: Motor torque constant (Nm/A),(0.0712 x 26 x 0.83)
float motor_inertia = 0.2144f;  //*26*26;           // Jn1: Motor inertia (kg·m²), (0.0003170 x 26 x 26)
float torque_constant_load = 1.5365f;       // Kt1: Load-side torque constant (Nm/A), (0.0712 x 26 x 0.83)
float disturbance_gain = 20.0f;             // Gdis1: DOB gain (~20Hz cutoff)
float reaction_gain = 20.0f;                // Grtob1: RTOB gain (~15Hz cutoff)
float internal_friction = 0.001f;//130f;          // Fint: Internal friction torque (Nm)
float viscous_friction = 0.0003f;           // Ffric: Viscous friction torque (Nm)
float pulses_per_revolution = 1024.0f;       // PPR: Encoder pulses per revolution
int motor_direction_flag = 0;
float dt_torque_constant_motor =0.0f;// Motor1DirB
uint16_t voltage_reference_1=0;
uint16_t voltage_reference_2=0;
// PI Controller gains for acceleration control
float proportional_gain = 5.01f;            // kp
float integral_gain = 0.001f;                // ki
float motor1MaxCurrent=3.0f;
// ────────────── ⏲️ Timing and Sampling ──────────────
float sampling_time = 0.001f;                 // dt_s: Set this appropriately in your loop

// ────────────── 📊 Observer and Control State Variables ──────────────
float previous_torque_error_integral = 0.0f;  // errorPreviousI1

// Output variables
float commanded_acceleration = 0.0f;
float inertia_compensation_current = 0.0f;
float disturbance_current = 0.0f;

// ────────────── 🔍 Disturbance Observer (DOB) Variables ──────────────
float estimated_motor_torque = 0.0f;
float estimated_velocity_disturbance = 0.0f;
float disturbance_observer_input = 0.0f;
float filtered_dob_input = 0.0f;
float filtered_dob_input_prev = 0.0f;
float estimated_torque_disturbance = 0.0f;

// ────────────── 🔍 Reaction Torque Observer (RTOB) Variables ──────────────
float updated_motor_torque = 0.0f;
float reaction_torque_input = 0.0f;
float filtered_reaction_torque = 0.0f;
float filtered_reaction_torque_prev = 0.0f;
float reaction_torque =0.0f;
float motor01_torque_profile_withtheta1 =0.0f;
float assit_torque = 0.0f;
// ────────────── ⚙️ Control Error Terms ──────────────
float desired_torque = 0.0f;                // Set externally per control target
float torque_error = 0.0f;
float torque_error_integral = 0.0f;
float motor_velocity = 0.0f;                // Set from encoder/sensor
// ────────────── ⚙️ Motor 2 Physical and Control Parameters ──────────────
float motor02_commanded_current = 0.0f;             // Commanded current (A)
float motor02_torque_constant = 1.5365f;            // Motor torque constant (Nm/A)
float motor02_inertia = 0.2144f;                 // Motor inertia (kg·m²)
float motor02_torque_constant_load = 1.5365f;       // Load-side torque constant (Nm/A)
float motor02_disturbance_gain = 20.1f;             // DOB gain (~20Hz cutoff)
float motor02_reaction_gain = 20.1f;                 // RTOB gain (~15Hz cutoff)
float motor02_internal_friction = 0.001f;          // Internal friction torque (Nm)
float motor02_viscous_friction = 0.0003f;           // Viscous friction torque (Nm)
float motor02_pulses_per_revolution = 1024.0f;       // Encoder pulses per revolution
float motor02_gear_ratio = 26.0f;                    // Gear ratio
int motor02_direction_flag = 0;                       // Motor direction flag

// PI Controller gains for acceleration control
float motor02_proportional_gain = 5.5f;            // kp
float motor02_integral_gain = 0.001f;                 // ki

// ────────────── ⏲️ Timing and Sampling ──────────────
float motor02_sampling_time = 0.001f;                  // dt_s (set appropriately)

// ────────────── 📊 Observer and Control State Variables ──────────────
float motor02_previous_torque_error_integral = 0.0f; // Integral error accumulator
bool reverse_motor2_encoder = true;  // Set to true to reverse Motor 2 encoder direction
// Output variables
float motor02_commanded_acceleration = 0.0f;
float motor02_inertia_compensation_current = 0.0f;
float motor02_disturbance_current = 0.0f;

// ────────────── 🔍 Disturbance Observer (DOB) Variables ──────────────
float motor02_estimated_motor_torque = 0.0f;
float motor02_estimated_velocity_disturbance = 0.0f;
float motor02_disturbance_observer_input = 0.0f;
float motor02_filtered_dob_input = 0.0f;
float motor02_filtered_dob_input_prev = 0.0f;
float motor02_estimated_torque_disturbance = 0.0f;

// ────────────── 🔍 Reaction Torque Observer (RTOB) Variables ──────────────
float motor02_updated_motor_torque = 0.0f;
float motor02_reaction_torque_input = 0.0f;
float motor02_filtered_reaction_torque = 0.0f;
float motor02_filtered_reaction_torque_prev = 0.0f;
float motor02_reaction_torque = 0.0f;
// ────────────── ⚙️ Control Error Terms ──────────────
float motor02_desired_torque = 0.0f;                  // Set externally per control target
float motor02_torque_error = 0.0f;
float motor02_torque_error_integral = 0.0f;
float motor02_motor_velocity = 0.0f;
float motor02_torque_profile_withtheta2 =0.0f;
// ────────────── 🚀 Acceleration Set Points ──────────────
float Set_Accelaration1 = 500;  // Desired acceleration
float Set_Torque1 = 0;  // Desired acceleration
float dt_s = 0.001f;
float ks=15.0f;
// ────────────── HAL Status ──────────────
HAL_StatusTypeDef status;
uint16_t OutputVref = 5000;         // DAC output voltage reference value
uint16_t ENABLEmOTOR = 1;         // DAC output voltage reference value

// ────────────── Low-pass Filter Function ──────────────
float applyLowPassFilterVelocity(float X, float Y_old) {
    // Apply the first-order low-pass filter formula
    float Y = Y_old + G *dt_s* (X - Y_old);  // Filtered value
    return Y;
}
float applyLowPassFilterVelocity2(float X, float Y_old) {
    // Apply the first-order low-pass filter formula
    float Y = Y_old + G2 *dt_s* (X - Y_old);  // Filtered value
    return Y;
}
float applyLowPassFilterAcceleration(float X, float Y_old) {
    float alpha = 0.05f;  // Adjust as needed (lower = smoother, higher = faster response)
    return Y_old + alpha * (X - Y_old);
}
// ────────────── Motor Control Functions ──────────────
void ConfigureMotor01(int Enable, int Clockwise, uint16_t dac_value) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, Clockwise);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, Enable);
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac_value);
}

void ConfigureMotor02(int Enable, int Clockwise, uint16_t dac_value) {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, Clockwise);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, Enable);
    HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, dac_value);
}
void UpdateMotor01CommandedCurrent(void)
{
    /*********************************************************
     *        Disturbance Observer for Motor 01             *
     *********************************************************/

    // Calculate motor torque from commanded current
    estimated_motor_torque = commanded_current * torque_constant_motor;

    // Estimate velocity disturbance
    estimated_velocity_disturbance = motor_velocity * motor_inertia * disturbance_gain;
    //estimated_velocity_disturbance = updated_motor_torque + motor_velocity * motor_inertia * reaction_gain - (internal_friction + viscous_friction * motor_velocity);
    // Input to disturbance observer filter
    disturbance_observer_input = estimated_motor_torque + estimated_velocity_disturbance;

    // Apply low-pass filter (difference equation form)
    filtered_dob_input = filtered_dob_input_prev + (disturbance_gain * sampling_time)* (disturbance_observer_input - filtered_dob_input_prev);
    filtered_dob_input_prev = filtered_dob_input;

    // Estimate torque disturbance and convert to equivalent current
    estimated_torque_disturbance = filtered_dob_input - estimated_velocity_disturbance;
    disturbance_current = estimated_torque_disturbance / torque_constant_motor;

    /*********************************************************
     *   Torque Observer + PI Controller to Set Acceleration
     *********************************************************/

    // Recompute torque with updated current (for reaction estimation)
    estimated_motor_torque = commanded_current * torque_constant_motor;

    // Estimate total reaction torque input (includes inertia and losses)
    estimated_velocity_disturbance = motor_velocity * motor_inertia * reaction_gain;
    //Delta torque_constant_motor,  Delta torque_constant_motor
    reaction_torque_input = estimated_motor_torque +  estimated_velocity_disturbance - (internal_friction + (viscous_friction * motor_velocity) - (dt_torque_constant_motor*commanded_current));

    // Apply low-pass filter for reaction torque estimate
    filtered_reaction_torque = filtered_reaction_torque_prev + (reaction_gain * sampling_time) * (reaction_torque_input - filtered_reaction_torque_prev);
    filtered_reaction_torque_prev = filtered_reaction_torque;

    // Subtract inertial effect to isolate external torque

    reaction_torque = filtered_reaction_torque - estimated_velocity_disturbance;
    //desired_torque = motor01_torque_profile_withtheta1;
    // PI Controller for acceleration control
    torque_error = (desired_torque - reaction_torque);
    torque_error_integral = (torque_error * sampling_time) + previous_torque_error_integral;
    previous_torque_error_integral = torque_error_integral;

    commanded_acceleration = (proportional_gain * torque_error) + (integral_gain * torque_error_integral);

    // Compute inertia-driven current command
    inertia_compensation_current = (motor_inertia * commanded_acceleration) / torque_constant_motor;

    // Final commanded current is inertia compensation + disturbance compensation
    //commanded_current = inertia_compensation_current + disturbance_current;
     commanded_current = inertia_compensation_current+ disturbance_current; //added for DOB tuning

}
void UpdateMotor02CommandedCurrent(void)
{
    /*********************************************************
     *  1. Disturbance Observer for Motor 02
     *********************************************************/

    // Calculate estimated motor torque
    motor02_estimated_motor_torque = motor02_commanded_current * motor02_torque_constant;

    // Estimate velocity disturbance
    motor02_estimated_velocity_disturbance = motor02_motor_velocity * motor02_inertia * motor02_disturbance_gain;

    // Input to disturbance observer filter
    motor02_disturbance_observer_input = motor02_estimated_motor_torque + motor02_estimated_velocity_disturbance;

    // Apply low-pass filter (difference equation form)
    motor02_filtered_dob_input = motor02_filtered_dob_input_prev + (motor02_disturbance_gain * motor02_sampling_time) *
                                 (motor02_disturbance_observer_input - motor02_filtered_dob_input_prev);
    motor02_filtered_dob_input_prev = motor02_filtered_dob_input;

    // Estimate torque disturbance and convert to equivalent current
    motor02_estimated_torque_disturbance = motor02_filtered_dob_input - motor02_estimated_velocity_disturbance;
    motor02_disturbance_current = motor02_estimated_torque_disturbance / motor02_torque_constant;

    /*********************************************************
     *   Torque Observer + PI Controller to Set Acceleration
     *********************************************************/

    // Recompute torque with updated current (for reaction estimation)
    motor02_updated_motor_torque = motor02_commanded_current * motor02_torque_constant;

    // Estimate total reaction torque input (includes inertia and losses)
    motor02_reaction_torque_input = motor02_updated_motor_torque + motor02_estimated_velocity_disturbance
                                    - (motor02_internal_friction + motor02_viscous_friction * motor02_motor_velocity);

    // Apply low-pass filter for reaction torque estimate
    motor02_filtered_reaction_torque = motor02_filtered_reaction_torque_prev + (motor02_reaction_gain * motor02_sampling_time) *
                                       (motor02_reaction_torque_input - motor02_filtered_reaction_torque_prev);
    motor02_filtered_reaction_torque_prev = motor02_filtered_reaction_torque;

    // Subtract inertial effect to isolate external torque
    motor02_reaction_torque = motor02_filtered_reaction_torque - (motor02_motor_velocity * motor02_inertia * motor02_reaction_gain);

    // PI Controller for acceleration control
    motor02_torque_error = motor02_desired_torque - (motor02_reaction_torque);
    motor02_torque_error_integral = (motor02_torque_error * motor02_sampling_time) + motor02_previous_torque_error_integral;
    motor02_previous_torque_error_integral = motor02_torque_error_integral;

    motor02_commanded_acceleration = (motor02_proportional_gain * motor02_torque_error) + (motor02_integral_gain * motor02_torque_error_integral);

    // Compute inertia-driven current command
    motor02_inertia_compensation_current = (motor02_inertia * motor02_commanded_acceleration) / motor02_torque_constant;

    // Final commanded current is inertia compensation + disturbance compensation
    motor02_commanded_current = motor02_inertia_compensation_current + motor02_disturbance_current;
}

void UpdateMotor02CommandedCurrentReversed(void)
{
    /*********************************************************
     *  1. Disturbance Observer for Motor 02
     *********************************************************/

    // Calculate estimated motor torque
    motor02_estimated_motor_torque = motor02_commanded_current * motor02_torque_constant;

    // Estimate velocity disturbance
    motor02_estimated_velocity_disturbance = (-1*motor02_motor_velocity) * motor02_inertia * motor02_disturbance_gain;

    // Input to disturbance observer filter
    motor02_disturbance_observer_input = motor02_estimated_motor_torque + motor02_estimated_velocity_disturbance;

    // Apply low-pass filter (difference equation form)
    motor02_filtered_dob_input = motor02_filtered_dob_input_prev + (motor02_disturbance_gain * motor02_sampling_time) *
                                 (motor02_disturbance_observer_input - motor02_filtered_dob_input_prev);
    motor02_filtered_dob_input_prev = motor02_filtered_dob_input;

    // Estimate torque disturbance and convert to equivalent current
    motor02_estimated_torque_disturbance = motor02_filtered_dob_input - (motor02_estimated_velocity_disturbance);
    motor02_disturbance_current = motor02_estimated_torque_disturbance / motor02_torque_constant;

    /*********************************************************
     *   Torque Observer + PI Controller to Set Acceleration
     *********************************************************/

    // Recompute torque with updated current (for reaction estimation)
    motor02_updated_motor_torque = motor02_commanded_current * motor02_torque_constant;

    // Estimate total reaction torque input (includes inertia and losses)
    motor02_reaction_torque_input = motor02_updated_motor_torque + (motor02_estimated_velocity_disturbance)
                                    - (motor02_internal_friction + (-1*motor02_viscous_friction * motor02_motor_velocity));

    // Apply low-pass filter for reaction torque estimate
    motor02_filtered_reaction_torque = motor02_filtered_reaction_torque_prev + (motor02_reaction_gain * motor02_sampling_time) *
                                       (motor02_reaction_torque_input - motor02_filtered_reaction_torque_prev);
    motor02_filtered_reaction_torque_prev = motor02_filtered_reaction_torque;

    // Subtract inertial effect to isolate external torque
    motor02_reaction_torque = motor02_filtered_reaction_torque - ((-1*motor02_motor_velocity) * motor02_inertia * motor02_reaction_gain);

    // PI Controller for acceleration control
    motor02_torque_error = motor02_desired_torque - (motor02_reaction_torque);
    motor02_torque_error_integral = (motor02_torque_error * motor02_sampling_time) + motor02_previous_torque_error_integral;
    motor02_previous_torque_error_integral = motor02_torque_error_integral;

    motor02_commanded_acceleration = (motor02_proportional_gain * motor02_torque_error) + (motor02_integral_gain * motor02_torque_error_integral);

    // Compute inertia-driven current command
    motor02_inertia_compensation_current = (motor02_inertia * motor02_commanded_acceleration) / motor02_torque_constant;

    // Final commanded current is inertia compensation + disturbance compensation
    motor02_commanded_current = motor02_inertia_compensation_current + motor02_disturbance_current;
}


int result = 0;

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM4_Init();
  MX_TIM13_Init();
  MX_SPI4_Init();
  MX_FATFS_Init();
  MX_DAC_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
  HAL_TIM_Encoder_Start(&htim1, TIM_CHANNEL_ALL);
  HAL_TIM_Base_Start(&htim2);
  HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
  HAL_DAC_Start(&hdac, DAC_CHANNEL_2);
  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of Record */
  osThreadDef(Record, StartDefaultTask, osPriorityNormal, 0, 128);
  RecordHandle = osThreadCreate(osThread(Record), NULL);

  /* definition and creation of MainController */
  osThreadDef(MainController, StartTask02, osPriorityRealtime, 0, 128);
  MainControllerHandle = osThreadCreate(osThread(MainController), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  DAC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC Initialization
  */
  hdac.Instance = DAC;
  if (HAL_DAC_Init(&hdac) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT1 config
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** DAC channel OUT2 config
  */
  if (HAL_DAC_ConfigChannel(&hdac, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief SPI4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI4_Init(void)
{

  /* USER CODE BEGIN SPI4_Init 0 */

  /* USER CODE END SPI4_Init 0 */

  /* USER CODE BEGIN SPI4_Init 1 */

  /* USER CODE END SPI4_Init 1 */
  /* SPI4 parameter configuration*/
  hspi4.Instance = SPI4;
  hspi4.Init.Mode = SPI_MODE_MASTER;
  hspi4.Init.Direction = SPI_DIRECTION_2LINES;
  hspi4.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi4.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi4.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi4.Init.NSS = SPI_NSS_SOFT;
  hspi4.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi4.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi4.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi4.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi4.Init.CRCPolynomial = 7;
  hspi4.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi4.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI4_Init 2 */

  /* USER CODE END SPI4_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 4;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 4;
  if (HAL_TIM_Encoder_Init(&htim1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 72*5-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 0xFFFFFFFF;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 8;
  sConfig.IC2Polarity = TIM_ICPOLARITY_FALLING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 8;
  if (HAL_TIM_Encoder_Init(&htim4, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief TIM13 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM13_Init(void)
{

  /* USER CODE BEGIN TIM13_Init 0 */

  /* USER CODE END TIM13_Init 0 */

  /* USER CODE BEGIN TIM13_Init 1 */

  /* USER CODE END TIM13_Init 1 */
  htim13.Instance = TIM13;
  htim13.Init.Prescaler = 14400-1;
  htim13.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim13.Init.Period = 999;
  htim13.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim13.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim13) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM13_Init 2 */

  /* USER CODE END TIM13_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_0|GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2|GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_0|GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pins : PF0 PF1 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PA2 PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD0 PD1 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
	  /*********************************************************
	   *                  Main Task Counter Update              *
	   *********************************************************/
	  MainTaskCount++;
	  time_start = __HAL_TIM_GET_COUNTER(&htim2);
	  MainloopCount++;
	  if (time_interval == 0) time_interval = 1;  // Safety check (avoid division by zero)

	  /*********************************************************
	   *                Read Encoder Tick Counts               *
	   *********************************************************/
	  EncoderUpdated = 0;
	  encoder_ticks = __HAL_TIM_GET_COUNTER(&htim1);   // Encoder 1
	  encoder_ticks2 = __HAL_TIM_GET_COUNTER(&htim4);  // Encoder 2
	  EncoderUpdated = 1;
	  /*********************************************************
	   *                 Time from Start (in sec)              *
	   *********************************************************/
	  secondFromStart = __HAL_TIM_GET_COUNTER(&htim2) / 100000;

	  /*********************************************************
	   *           Compute Position, Velocity, Acceleration    *
	   *                  For Encoder 1 (Motor 1)              *
	   *********************************************************/

	  // Persistent variable
	  static int16_t prev_ticks1 = 0;

	  // Read current encoder count
	  int16_t curr_ticks1 = __HAL_TIM_GET_COUNTER(&htim1);
	  int16_t delta_ticks1 = (int16_t)(curr_ticks1 - prev_ticks1);  // Handles overflow
	  prev_ticks1 = curr_ticks1;

	  // Compute delta angle and accumulate
	  float delta_theta1 = ((float)delta_ticks1) * 2.0f * M_PI / CPR;
	  theta1 += delta_theta1;


	  // Velocity and acceleration
	  velocity1 = (theta1 - theta1_prev) / dt_s;
	  motor_velocity = velocity1_prev + G *dt_s* (velocity1 - velocity1_prev);
	  velocity1_prev = motor_velocity;
	  //float raw_acceleration1 = (velocity1 - velocity1_prev) / dt_s;
	  //acceleration1 = (1 - 0.1f) * acceleration1 + 0.1f * raw_acceleration1;  // Low-pass filter

	  // Apply velocity filter
	  //motor_velocity = applyLowPassFilterVelocity(velocity1, velocity1_prev);

	  // Update previous states
	  // THEN update for next loop
	  theta1_prev = theta1;



	  /*********************************************************
	   *           Compute Position, Velocity, Acceleration    *
	   *                  For Encoder 2 (Motor 2)              *
	   *********************************************************/

	  // Persistent variable
	  static int16_t prev_ticks2 = 0;

	  // Read current encoder count
	  int16_t curr_ticks2 = __HAL_TIM_GET_COUNTER(&htim4);
	  //int16_t delta_ticks2 = (int16_t)(curr_ticks2 - prev_ticks2);  // Handles overflow
	  // Compute delta and reverse if needed
	  int16_t delta_ticks2 = (int16_t)(curr_ticks2 - prev_ticks2);
	  prev_ticks2 = curr_ticks2;

	  // Compute delta angle and accumulate
	  float delta_theta2 = ((float)delta_ticks2) * -2.0f * M_PI / CPR;
	  theta2 += delta_theta2;


	  // Velocity and acceleration
	  velocity2 = (theta2 - theta2_prev) / dt_s;
	  float raw_acceleration2 = (velocity2 - velocity2_prev) / dt_s;
	  acceleration2 = (1 - 0.1f) * acceleration2 + 0.1f * raw_acceleration2;  // Low-pass filter

	  // Apply velocity filter
	  motor02_motor_velocity = applyLowPassFilterVelocity2(velocity2, velocity2_prev);

	  // Update previous states
	  theta2_prev = theta2;
	  velocity2_prev = motor02_motor_velocity;
	  UpdateMotor01CommandedCurrent();
	  //UpdateMotor02CommandedCurrent();
	  UpdateMotor02CommandedCurrentReversed();

	 assit_torque = -ks*(theta1-theta2);
	 motor02_desired_torque = motor02_torque_profile_withtheta2 - assit_torque;
	  /*********************************************************
	   *         Motor Output Control & Saturation            *
	   *********************************************************/
	  // Limit commanded current to ±3.0 A and set motor direction
	  if (commanded_current > motor1MaxCurrent) {
	      commanded_current = motor1MaxCurrent;
	      motor_direction_flag = 1;  // Forward
	      voltage_reference_1 = (4095.0f / motor1MaxCurrent) * fabsf(commanded_current);
	  }
	  else if (commanded_current < -3.0f) {
	      commanded_current = -3.0f;
	      motor_direction_flag = 0;  // Reverse
	      voltage_reference_1 = (4095.0f / motor1MaxCurrent) * fabsf(-1*commanded_current);
	  }
	  else {
	      // Current is within safe bounds; determine direction by sign
	      if (commanded_current >= 0.0f) {
	          motor_direction_flag = 1;  // Forward
	          voltage_reference_1 = (4095.0f /motor1MaxCurrent) * fabsf(commanded_current);
	      } else {
	          motor_direction_flag = 0;  // Reverse
	          voltage_reference_1 = (4095.0f / motor1MaxCurrent) * fabsf(-1*commanded_current);
	      }
	  }

	  // Convert current to PWM duty cycle (12-bit scale), store in voltage_reference_1


	  // Apply output using reference voltage and direction
	  ConfigureMotor01(ENABLEmOTOR, motor_direction_flag, voltage_reference_1);
	  // Limit commanded current to ±3.0 A and set motor direction
	  if (motor02_commanded_current > 3.0f) {
		  motor02_commanded_current = 3.0f;
		  motor02_direction_flag = 1;  // Forward direction
		  voltage_reference_2 = (4095.0f / 3.0f) * fabsf(motor02_commanded_current);
	  }
	  else if (motor02_commanded_current < -3.0f) {
		  motor02_commanded_current = -3.0f;
		  motor02_direction_flag = 0;  // Reverse direction
		  voltage_reference_2 = (4095.0f / 3.0f) * fabsf(-1*motor02_commanded_current);
	  }
	  else {
	      // Current is within safe bounds; determine direction by sign
	      if (motor02_commanded_current >= 0.0f) {
	    	  motor02_direction_flag = 1;  // Forward
	    	  voltage_reference_2 = (4095.0f / 3.0f) * fabsf(motor02_commanded_current);
	      } else {
	    	  motor02_direction_flag = 0;  // Reverse
	          voltage_reference_2 = (4095.0f / 3.0f) * fabsf(-1*motor02_commanded_current);
	      }
	  }

	  // Convert commanded current to PWM duty cycle (12-bit scale)
	  // Assuming 3.3V corresponds to max current of 3A
	  //voltage_reference_2 = (4096.0f / 3.3f) * fabsf(motor02_commanded_current);

	  ConfigureMotor02(ENABLEmOTOR, motor02_direction_flag, voltage_reference_2);
	  // Apply output using reference voltage and direction
	  //ConfigureMotor02(ENABLEmOTOR, Motor1DirB, Icmd1 * (4096) / 3.3);

	  /*********************************************************
	   *               Update Time Interval                   *
	   *********************************************************/

	  osDelay(2);
	  time_end = __HAL_TIM_GET_COUNTER(&htim2);

  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the DataRecordTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void const * argument)
{
  /* USER CODE BEGIN StartTask02 */
  /* Infinite loop */
  for(;;)
  {


	if (SDCardRecordMode==1){
    SDCardCount++;
    if (EncoderUpdated == 1 && communicationError==0) {
        FRESULT fr;
        UINT bytes_written;

        // Open the file for appending
        fr = f_open(&fil, "Data.txt", FA_OPEN_APPEND | FA_WRITE);
        if (fr != FR_OK) {
            // Optional: Handle error (blink LED, set flag, etc.)
        	communicationError=1;
            return;
        }

        // Format the record number and encoder tick data into a string
        sprintf(buffer, "R%lu: E1: %lu, E2: %lu\n", SDCardCount, encoder_ticks, encoder_ticks2);
        //"R%lu: E1: %lu, E2: %lu\n"
        // Write to the file
        fr = f_write(&fil, buffer, strlen(buffer), &bytes_written);
        if (fr != FR_OK || bytes_written == 0) {
            f_close(&fil);  // Close anyway if open
            communicationError=1;
            return;
        }

        // Close the file
        fr = f_close(&fil);
        if (fr != FR_OK) {
        	communicationError=1;
            return;
        }

        EncoderUpdated = 0;
        record_number++;
    }
	}
	else {
		// ===== STM32 Side (Master - Transmitter) =====
		// Transmit 1 int + 5 floats (20 bytes) + start marker (1 byte) + CRC (1 byte) = 22 bytes

		uint8_t txBuf[22];
		uint8_t rxBuf[22];

		memset(txBuf, 0, sizeof(txBuf));
		memset(rxBuf, 0, sizeof(rxBuf));  // 💡 Important flush

		txBuf[0] = 0xAA;
		memcpy(&txBuf[1],  &time_start, sizeof(int));
		memcpy(&txBuf[5],  &reaction_torque_input, sizeof(float));
		memcpy(&txBuf[9],  &desired_torque, sizeof(float));
		memcpy(&txBuf[13], &theta1, sizeof(float));
		memcpy(&txBuf[17], &theta2, sizeof(float));

		// CRC
		uint8_t crc = 0;
		for (int i = 0; i < 21; i++) {
		    crc ^= txBuf[i];
		}
		txBuf[21] = crc;

		// SPI transmit
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_Delay(1);
		HAL_SPI_TransmitReceive(&hspi4, txBuf, rxBuf, sizeof(txBuf), HAL_MAX_DELAY);
		HAL_Delay(1);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
		HAL_Delay(1);  // can increase to 3–5 ms if instability persists
  // Delay before next cycle
	}

	osDelay(5);
  }
}
  /* USER CODE END StartTask02 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM5 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM5)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
